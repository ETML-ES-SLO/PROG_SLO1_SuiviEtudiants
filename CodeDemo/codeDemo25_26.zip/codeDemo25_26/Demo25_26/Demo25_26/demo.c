//-----------------------------------------------------------------------------------//
// Project Name 		: Demo25_26
// File name 			: demo.c
// Date de cr�ation 	: 29.09.2025
// Date de modification : 15.12.2025
//
// Auteur 				: Philou (Ph. Bovey)
//
// Version				: 1.3
//
// Description          : demo pour SLO1 25-26
//						  -> type 
//						  -> variable - tableau 
//						  -> condition - it�ration
//						  -> appel de fontion - utilisation lib perso + standard 
// 
// Remarques			: une constante num�rique enti�re -> ex 10 prend 4 octets 
//						  une constante num�rique r�elle -> ex 3.14 prend 8 octets             
//----------------------------------------------------------------------------------//

//-- librairie standard --// 
	// lib pour les entr�e - sortie (console - lecture clavier)
	// lib pour le entier normalis� 
	// lib pour le type bool 
	// pour la gestion des chaine de caract�re

//-- librairie perso --//  


//-- d�finition --// 
#define ANNEES "25-26"
#define VERSION 1.1


//-- d�finition structure local par rapport au fichier --// 


//-- constante gloable --// 


//----------------------------------------------------------------------------------//
//-- nom fct : main
//-- param�tre entr�e : -
//-- param�tre sortie : - 
//-- param�tre IN-OUT : - 
//-- description : programme principal =>
//----------------------------------------------------------------------------------//
void main()
{
	//-- constante --// 
	//-- reel 
	//-- � �viter -> si possible -> raison gestion m�moire 
	/*const float PI_v1 = 3.14;
	const float FOIX_2_2 = 2;*/

	//-- variables --//
	//--- Entier Standard 
	//--- Sign� (+/-)
		// 1 octet
		// 2 octets 
		// 4 octets			
		// 8 octets 
	
	//-- tabeau entier de 1o
		// 10 octet

	//-- tableau entier de 2 octets 
	

	//--- Non sign� (+) 
		// 1 octet
		// 2 octets 
		// 4 octets			
		// 8 octets 


	//--- Entier Notrmalis� -> librairie stdint.h 
		//--- Sign� (+/-)
	int8_t varA;		// 1 octet
	int16_t varB;		// 2 octets 
	int32_t varC;			// 4 octets			int = long 
	int64_t varD;	// 8 octets 

	//--- Non sign� (+) 
	uint8_t varE;		// 1 octet
	uint16_t varF;		// 2 octets 
	uint32_t varG;			// 4 octets			int = long 
	uint64_t varH;	// 8 octets 

	//-- type entier type bool�en --//
	bool varS;		// 1 octet

	//--> info user 
	printf("Code demo - SLO - %s - %2.1f \n", ANNEES, VERSION);

	//--> message user -> info taille 
	printf("\n-> taille d'un booleen %d [o]", sizeof(bool));
	printf("\n-> taille du tableau multidimension Q11B : %d [o]", sizeof(result));


	//--d�finition d'un type enum�ration -> e_machineEtat -> locale --// 
					  //ETAT1 = 0, ETAT2 = 20, ETAT3 = 21
	enum e_machineEtat { AVANCE, RECULE = 20, TOURNE_G, TOURNE_D, ROTATION };
	enum e_machineEtat robot = AVANCE;

	//-- utilisation d'une �num�ration globale -> e_FORME --// 
	e_FORME formeGeo = RECTANGLE;

	//-- d�claration structure --// 
	//-- local //-- type //-- variable 
	struct str_GestLED mesLeds; 


	// -- type		//-- variable 
	str_transistor monTransistor = { 100, 0.7, {0}};
	str_enteteEthernet ethernet; 
	
	varK = sizeof(str_enteteEthernet); 

								//led R, G, B, lum, nb
	struct str_GestLED mesleds2 = {0, 0, 0, 0.0, &tbExemple[0]};

	mesLeds.LedB = 0; 


	// -- gestion union 
	u_ethernet ethernet2; 

					  //MSB - LSB
	ethernet2.trame = 0x12345678; 
	
	varI = ethernet2.decodageTrame.version; 
	varI = ethernet2.decodageTrame.longueurEntete; 
	varF = ethernet2.decodageTrame.longeurTotal; 


	//-- lecture �criture --// 
	gestionFichier(); 


	//-- passage par r�f�rence --//
	DemoStruct(&monTransistor); 


	//-- MAJ de la variable enum
	robot = RECULE;

	printf("\n-> taille de l'enum robot %d [o]", sizeof(robot));

	printf("\n-> taille du tableau %d [o]", sizeof(tbExemple));

	//--- Reel 
	//-> taille 4 octets
	float perimetre1_m, perimetre2_m, perimetre3_m, vF;
	float tbnote[] = {3.5, 6, 4.0};
	float moyenne; 

	// cast implcite -> entier -> reel
	float rayon_m = 10;          // _m => metre 

	//-> taille 8 octets 
	double varR;

	// -> pour tester 10 case -> soit < 10 ou <= 9
	// -> remplir un tableau en partant de la lettre 'A'
	for (i = 0; i <= TAILLE_TB - 1; i++)
	{
		// -> Ox41 correspond au 'A'	(voir table ASCII) 
		tbExemple[i] = 0X41 + i;
		
		// -> affichage de chaque caract�re 
		printf("%c ", i);
	}

	// -> exemple de r�cuperation d'une valeur d'un tableau 
	i = tbExemple[9];

	// -> exemple d'un 
	moyenne = (tbnote[0] + tbnote[2]) / 2; 


	//-- une imstruction  est compos� d'op�randes (variable) et d'op�rateur (signe) --//
	//-- cast => (type)variable 
	perimetre1_m = (float)FOIX_2 * (float)PI * rayon_m;

	//-- attention au cast implicite
	perimetre2_m = (float)(FOIX_2 * PI * rayon_m);

	//-- appel de fct 
	//--> calcul perimetre ccercle 
	perimetre3_m = CalculPerimetreCercle(rayon_m);

	//--> calcul d'une moyenne
	moyenne = CalculMoyenne();

	//-> message user 
	DemoAffichage(); 
	
	//--> perim�tre 
	printf("\n->demo calcul permimetre perimetre1 : %f \n", perimetre1_m);
	printf("perimetre2 %f \n", perimetre2_m);
	printf("perimetre3 %f", perimetre3_m);

	//--> moyenne
	printf("\n-> calul moyenne %3.2f", moyenne);

	//-- condition -> expression
	varI = 'C';
	varJ = 10;

	//-- condition prioritaire 
	if (varI > varJ)
	{
		//-- condition secondaire 
		//if (0);
		varJ++;				//post incr�mentation 
		varI = varJ;
		--varJ;				//pre incr�mentation
		varJ += 1;			// varJ = varJ + 1

	}
	else if (varI == varJ)
	{

	}
	else
	{
		varJ--;
	}


	//-- machine �tat --//
	switch (formeGeo)
	{
	case CERCLE:
		//-- instruction 1... 
		//-- instruction 2... 
		break;

	case TRIANGLE:
		break;

	case RECTANGLE:
	case CARRE:
		//-- instruction 1... 
		//-- instruction 2... 

		break;

	default:
		break;
	}


	//-- it�ration  --// 

	//--> 1 contion  -> 2 execution si vrai 
	//-- boucle infinie 
	//while (1) {}

	i = 0; 
	j = 100; 
	while(i < j)
	{ 
		i++; 
		j--; 
	}

	//-- au minium une fois dans la boucle
	i = 0;
	j = 100;
	do 
	{
		i++;
		j--;
	} while (i < j);

			
	//-- pour les compteur --> connait le nombre d'it�ration
	//-- boucle � l'infini --// 
	//for (;;)
	{

	}

	//->1) initialisation plusieurs variables 2) condition 3) 
	for(i = 0, j = 100; i < j; i++, j--)
	{
	
	}




}
















