//-----------------------------------------------------------------------------------//
// Nom du projet 		: Demo25_26
// Nom du fichier 		: affichage.c
// Date de cr�ation 	: 08.12.2025
// Date de modification : xx.xx.2025
//
// Auteur 				: Philou (Ph. Bovey)
//
// Version				: 0.1
//
// Description          : demo pour SLO1 25-26
//
// Remarques			: 
//----------------------------------------------------------------------------------//

//-- librairie standard --//
#include <stdio.h>

//-- librairie perso --//  
#include "interfaceUser.h"


//----------------------------------------------------------------------------------//
//-- nom fct : DemoAffichage
//-- param�tre entr�e : -
//-- param�tre sortie : -
//-- param�tre IN-OUT : - 
//-- description	  : => op�rateur de conversion 
//					  : %c -> caract�re 
//				      : %d -> entier 
//					  : %f -> reel 
//----------------------------------------------------------------------------------//
void DemoAffichage()
{
	char version = 50; 

	//short 

	printf("\n");	// retour chariot + saut de page 

	//-- affichage d'une chaine de caract�re directement --// 
	printf("DEMO SLO");

	//-- --//
	printf("%c", version); 

}


void DemoStruct(str_transistor *transistor)
{

	transistor->Vbe = 0.6; 
	
	(*transistor).gain = 120; 
}