//-----------------------------------------------------------------------------------//
// Nom du projet 		: Demo25_26
// Nom du fichier 		: ConversionPerso.c
// Date de cr�ation 	: 03.11.2025
// Date de modification : 14.11.2025
//
// Auteur 				: Philou (Ph. Bovey)
//
// Version				: 1.1
//
// Description          : demo pour SLO1 25-26
//
// Remarques			: exemple d'op�rateur : 
//						  op�rateur math�mnatique		   : +, -, *, /					-> avec E ou R 
//														   : %							-> modulo avec uniquement E
//						  op�rateur logique				   : &, |, !, ^, ~, << , >>		-> ET - OU - NOT - /!\ XOR - inversion binaire 	 
//						  op�rateur de condition num�rique : ==, !=, <, <=, >, >=   
//						  op�rateur de condition logique   : ||, && 
//----------------------------------------------------------------------------------//
#define _USE_MATH_DEFINES		// pour utiliser des constantes li�s � la librairie 
								// math 

//-- librairie standard --// 
#include <math.h>
//#include <corecrt_math_defines.h>		// autre possibilit� pour utiliser les cst de
										// de la librairie math

//-- librairie perso --//  
#include "Conversion.h"


//----------------------------------------------------------------------------------//
//-- nom fct : CalculPerimetreCercle
//-- param�tre entr�e : rayon_m (reel)
//-- param�tre sortie : perimetre_m (reel)
//-- param�tre IN-OUT : - 
//-- description	  : calculer le perim�tre d'un cercle
//----------------------------------------------------------------------------------//
float CalculPerimetreCercle(float rayon_m)
{
	//-- d�claration et initialisation cst --// 
	const float DEUX_PI = 2 * M_PI;

	//-- d�claration variable --// 
	float perimetre_m;

	//-- calcul perimetre --//
	perimetre_m = DEUX_PI * rayon_m;

	//-- retour perimetre --// 
	return (perimetre_m);
}

//----------------------------------------------------------------------------------//
//-- nom fct : CalculMoyenne
//-- param�tre entr�e : - 
//-- param�tre sortie : moyenne (reel 4 octet) 
//-- param�tre IN-OUT : - 
//-- description	  : calcul la moyenne d'une nombre de notes d�finis 
//----------------------------------------------------------------------------------//
float CalculMoyenne()
{
	//-- d�claration de variables --// 
	float note1 = 3, note2 = 4.5, note3 = 6.0, somme = 0, moyenne; 

	//-- calcul de la somme 
	//-- m�thode 1 
	#if defined (METHODE_1)					//-> d�but pragma pour du versionning de soft
	somme = note1 + note2 + note3; 

	#elif defined (METHODE_2)				//-> pragma pour du versionning de soft
	//-- m�thode 2 
	somme = somme + note1; 
	somme = somme + note2; 
	somme = somme + note3; 

	#elif defined (METHODE_3)				//-> pragma pour du versionning de soft
	//-- m�thode 3
	somme += note1; 
	somme += note2;
	somme += note3;
	#endif									//-> fin pragma pour du versionning de soft

	//-- calcul de la moyenne pr�d�fini
	moyenne = somme / NB_NOTES_MAX; 
	
	return moyenne; 
}

